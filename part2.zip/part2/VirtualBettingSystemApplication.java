import javax.swing.*;
import java.awt.event.*;

public class VirtualBettingSystemApplication {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Virtual Betting System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setSize(400, 200);
        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel horseLabel = new JLabel("Select Horse:");
        horseLabel.setBounds(10, 20, 120, 25);
        panel.add(horseLabel);

        String[] horseOptions = {"Horse 1", "Horse 2", "Horse 3"};
        JComboBox<String> horseComboBox = new JComboBox<>(horseOptions);
        horseComboBox.setBounds(140, 20, 200, 25);
        panel.add(horseComboBox);

        JLabel betLabel = new JLabel("Bet Amount:");
        betLabel.setBounds(10, 50, 120, 25);
        panel.add(betLabel);

        JTextField betTextField = new JTextField();
        betTextField.setBounds(140, 50, 200, 25);
        panel.add(betTextField);

        JButton betButton = new JButton("Place Bet");
        betButton.setBounds(140, 80, 120, 25);
        panel.add(betButton);

        betButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedHorse = (String) horseComboBox.getSelectedItem();
                String betAmount = betTextField.getText();
                if (!betAmount.isEmpty()) {
                    JOptionPane.showMessageDialog(panel,
                            "Bet placed successfully on " + selectedHorse + " for $" + betAmount,
                            "Bet Placed",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(panel,
                            "Please enter a bet amount.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
