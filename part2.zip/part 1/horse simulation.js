/**
 * The Horse class represents a horse in a game or simulation.
 * It keeps track of the horse's name, symbol, confidence rating,
 * distance travelled, and whether it has fallen.
 *
 * @author [Your Name]
 * @version 1.0
 */
public class Horse {
    // Fields of class Horse
    private char symbol;
    private String name;
    private double confidenceRating;
    private int distanceTravelled;
    private boolean hasFallen;

    // Constructor of class Horse
    /**
     * Constructor for objects of class Horse
     * @param horseSymbol The symbol representing the horse
     * @param horseName The name of the horse
     * @param horseConfidence The initial confidence rating of the horse (between 0 and 1)
     */
    public Horse(char horseSymbol, String horseName, double horseConfidence) {
        symbol = horseSymbol;
        name = horseName;
        confidenceRating = validateConfidence(horseConfidence);
        distanceTravelled = 0;
        hasFallen = false;
    }

    // Other methods of class Horse
    public void fall() {
        hasFallen = true;
    }

    public double getConfidence() {
        return confidenceRating;
    }

    public int getDistanceTravelled() {
        return distanceTravelled;
    }

    public String getName() {
        return name;
    }

    public char getSymbol() {
        return symbol;
    }

    public void goBackToStart() {
        distanceTravelled = 0;
    }

    public boolean hasFallen() {
        return hasFallen;
    }

    public void moveForward() {
        distanceTravelled++;
    }

    public void setConfidence(double newConfidence) {
        confidenceRating = validateConfidence(newConfidence);
    }

    public void setSymbol(char newSymbol) {
        symbol = newSymbol;
    }

    // Private helper method to ensure confidence rating is within range [0, 1]
    private double validateConfidence(double confidence) {
        if (confidence < 0)
            return 0;
        else if (confidence > 1)
            return 1;
        else
            return confidence;
    }

    // Example usage
    public static void main(String[] args) {
        // Create a new Horse instance
        Horse myHorse = new Horse('\u265E', "PIPPI LONGSTOCKING", 0.8);

        // Print the initial state of the Horse
        System.out.println("Name: " + myHorse.getName());
        System.out.println("Symbol: " + myHorse.getSymbol());
        System.out.println("Confidence: " + myHorse.getConfidence());
        System.out.println("Distance Travelled: " + myHorse.getDistanceTravelled());
        System.out.println("Has Fallen: " + myHorse.hasFallen());

        // Perform some actions on the Horse
        myHorse.moveForward();
        System.out.println("\nAfter moving forward:");
        System.out.println("Distance Travelled: " + myHorse.getDistanceTravelled());

        myHorse.setConfidence(0.5);
        System.out.println("New Confidence: " + myHorse.getConfidence());

        myHorse.fall();
        System.out.println("Has Fallen: " + myHorse.hasFallen());
    }
}