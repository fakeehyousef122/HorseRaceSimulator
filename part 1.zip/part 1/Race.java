import java.util.concurrent.TimeUnit;
import java.lang.Math;

/**
 * A class representing a horse in a race.
 */
class Horse {
    private char symbol;
    private String name;
    private double confidenceRating;
    private int distanceTravelled;
    private boolean hasFallen;

    public Horse(char symbol, String name, double confidenceRating) {
        this.symbol = symbol;
        this.name = name;
        this.confidenceRating = validateConfidence(confidenceRating);
        this.distanceTravelled = 0;
        this.hasFallen = false;
    }

    public void fall() {
        hasFallen = true;
    }

    public double getConfidence() {
        return confidenceRating;
    }

    public int getDistanceTravelled() {
        return distanceTravelled;
    }

    public String getName() {
        return name;
    }

    public char getSymbol() {
        return symbol;
    }

    public void goBackToStart() {
        distanceTravelled = 0;
    }

    public boolean hasFallen() {
        return hasFallen;
    }

    public void moveForward() {
        distanceTravelled++;
    }

    private double validateConfidence(double confidence) {
        if (confidence < 0) {
            return 0;
        } else if (confidence > 1) {
            return 1;
        } else {
            return confidence;
        }
    }

    public String toString() {
        return "| " + symbol + " | " + name + " (Current confidence " + confidenceRating + ")";
    }
}

/**
 * A three-horse race, each horse running in its own lane
 * for a given distance
 *
 * @author McFarewell
 * @version 1.0
 */
public class Race {
    private int raceLength;
    private Horse lane1Horse;
    private Horse lane2Horse;
    private Horse lane3Horse;

    /**
     * Constructor for objects of class Race
     * Initially there are no horses in the lanes
     *
     * @param distance the length of the racetrack (in metres/yards...)
     */
    public Race(int distance) {
        // initialise instance variables
        raceLength = distance;
        lane1Horse = null;
        lane2Horse = null;
        lane3Horse = null;
    }

    /**
     * Adds a horse to the race in a given lane
     *
     * @param theHorse   the horse to be added to the race
     * @param laneNumber the lane that the horse will be added to
     */
    public void addHorse(Horse theHorse, int laneNumber) {
        if (laneNumber == 1) {
            lane1Horse = theHorse;
        } else if (laneNumber == 2) {
            lane2Horse = theHorse;
        } else if (laneNumber == 3) {
            lane3Horse = theHorse;
        } else {
            System.out.println("Cannot add horse to lane " + laneNumber + " because there is no such lane");
        }
    }

    /**
     * Start the race
     * The horses are brought to the start and
     * then repeatedly moved forward until the
     * race is finished
     */
    public void startRace() {
        boolean finished = false;
        Horse winningHorse = null; // Initialize winningHorse to null

        if (lane1Horse != null) {
            lane1Horse.goBackToStart();
        }
        if (lane2Horse != null) {
            lane2Horse.goBackToStart();
        }
        if (lane3Horse != null) {
            lane3Horse.goBackToStart();
        }

        while (!finished) {
            if (lane1Horse != null) {
                moveHorse(lane1Horse);
            }
            if (lane2Horse != null) {
                moveHorse(lane2Horse);
            }
            if (lane3Horse != null) {
                moveHorse(lane3Horse);
            }

            printRace();

            // Update winningHorse if a horse has traveled a greater distance
            if (lane1Horse != null && (winningHorse == null || lane1Horse.getDistanceTravelled() > winningHorse.getDistanceTravelled())) {
                winningHorse = lane1Horse;
            }
            if (lane2Horse != null && lane2Horse.getDistanceTravelled() > winningHorse.getDistanceTravelled()) {
                winningHorse = lane2Horse;
            }
            if (lane3Horse != null && lane3Horse.getDistanceTravelled() > winningHorse.getDistanceTravelled()) {
                winningHorse = lane3Horse;
            }

            if ((lane1Horse != null && raceWonBy(lane1Horse)) || (lane2Horse != null && raceWonBy(lane2Horse)) || (lane3Horse != null && raceWonBy(lane3Horse))) {
                finished = true;
            }

            try {
                TimeUnit.MILLISECONDS.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Print the winning horse's name
        if (winningHorse != null) {
            System.out.println("And the winner is " + winningHorse.getName());
        } else {
            System.out.println("No horses were added to the race.");
        }
    }

    /**
     * Randomly make a horse move forward or fall depending
     * on its confidence rating
     * A fallen horse cannot move
     *
     * @param theHorse the horse to be moved
     */
    private void moveHorse(Horse theHorse) {
        // if the horse has fallen it cannot move,
        // so only run if it has not fallen
        if (!theHorse.hasFallen()) {
            // the probability that the horse will move forward depends on the confidence;
            if (Math.random() < theHorse.getConfidence()) {
                theHorse.moveForward();
            }

            // the probability that the horse will fall is very small (max is 0.1)
            // but will also will depends exponentially on confidence
            // so if you double the confidence, the probability that it will fall is *2
            if (Math.random() < (0.1 * theHorse.getConfidence() * theHorse.getConfidence())) {
                theHorse.fall();
            }
        }
    }

    /**
     * Determines if a horse has won the race
     *
     * @param theHorse The horse we are testing
     * @return true if the horse has won, false otherwise.
     */
    private boolean raceWonBy(Horse theHorse) {
        return theHorse.getDistanceTravelled() == raceLength;
    }

    /**
     * Print the race on the terminal
     */
    private void printRace() {
        System.out.print('\u000C'); // clear the terminal window

        printTrackEdge();

        if (lane1Horse != null) {
            printLane(lane1Horse);
            System.out.println();
        }

        if (lane2Horse != null) {
            printLane(lane2Horse);
            System.out.println();
        }

        if (lane3Horse != null) {
            printLane(lane3Horse);
            System.out.println();
        }

        printTrackEdge();
        System.out.println();
    }

    /**
     * Print top and bottom edges of the racetrack
     */
    private void printTrackEdge() {
        multiplePrint('=', raceLength + 3);
        System.out.println();
    }

    /**
     * print a horse's lane during the race
     * for example
     * |           X                      |
     * to show how far the horse has run
     */
    private void printLane(Horse theHorse) {
        // calculate how many spaces are needed before
        // and after the horse
        int spacesBefore = theHorse.getDistanceTravelled();
        int spacesAfter = raceLength - theHorse.getDistanceTravelled();

        // print a | for the beginning of the lane
        System.out.print('|');

        // print the spaces before the horse
        multiplePrint(' ', spacesBefore);

        // print the horse
        System.out.print(theHorse);

        // print the spaces after the horse
        multiplePrint(' ', spacesAfter);

        // print a | for the end of the lane
        System.out.print('|');
    }

    /**
     * Print a character multiple times
     *
     * @param c     the character to be printed
     * @param times the number of times to print it
     */
    private void multiplePrint(char c, int times) {
        for (int i = 0; i < times; i++) {
            System.out.print(c);
        }
    }

    /**
     * A simple test for the Race class.
     */
    public static void main(String[] args) {
        Race race = new Race(10);

        Horse horse1 = new Horse('♘', "PIPPI LONGSTOCKING", 0.6);
        Horse horse2 = new Horse('♞', "KOKOMO", 0.6);
        Horse horse3 = new Horse('❌', "EL JEFE", 0.4);

        race.addHorse(horse1, 1);
        race.addHorse(horse2, 2);
        race.addHorse(horse3, 3);

        race.startRace();
    }
}
